One Launcher - Modern Edition 1.1.0

Updates:
- First-run Welcome screen with Get Started action.
- Modern translucent clock/date widget.
- Google search bar on the first home page.
- Colorful gradient background and glass-style panels.
- Existing app drawer, app search, long-press actions, dock, and swipe navigation retained.

Build APK:
1. Open this folder (OneLauncher) in Android Studio.
2. Allow Gradle sync to finish.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).

Command line (from this folder):
  gradle assembleDebug

APK output:
  app/build/outputs/apk/debug/app-debug.apk

Minimum Android version: Android 8.0 (API 26).
